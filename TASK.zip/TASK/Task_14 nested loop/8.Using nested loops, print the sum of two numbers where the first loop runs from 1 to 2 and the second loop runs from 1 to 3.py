for i in range(1,3):
    for j in range(1,4):
        print(f'{i}+{j}={i+j}',end="\n")
    print()