i=6
sum=0
for i in range(1,6):
    sum=sum+i
print(sum)
