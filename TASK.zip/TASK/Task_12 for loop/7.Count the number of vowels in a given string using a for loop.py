word="himalaya"
VOWELS="aeiou"
count=1
for VOWELS in word:
    if VOWELS in word: 
        print(count)
        count+=1