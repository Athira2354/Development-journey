list=[10,11,12,13,14,15,16,17]

max=0

second_max=0

for num
